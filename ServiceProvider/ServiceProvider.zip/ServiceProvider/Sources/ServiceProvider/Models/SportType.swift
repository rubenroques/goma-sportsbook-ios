//
//  File.swift
//  
//
//  Created by Ruben Roques on 10/10/2022.
//

import Foundation
 
public enum SportType {
    case football
}
    
