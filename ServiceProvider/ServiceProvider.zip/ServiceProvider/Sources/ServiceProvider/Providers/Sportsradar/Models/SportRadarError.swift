//
//  SportRadarError.swift
//  
//
//  Created by Ruben Roques on 10/10/2022.
//

import Foundation

enum SportRadarError: Error {
    case unkownSportId
}
