//
//  SportRadarSessionAccessToken.swift
//  
//
//  Created by Ruben Roques on 07/10/2022.
//

import Foundation

struct SportRadarSessionAccessToken: SessionAccessToken {
    var hash: String
}
